package com.itwillbs.service;

import java.util.List;

import com.itwillbs.domain.CommonVO;

public interface SystemService {
	
	public void registCommons(CommonVO cvo) throws Exception;
	public List<CommonVO> getCommons() throws Exception;
	public CommonVO getOneCommon(CommonVO cvo) throws Exception;
}
