package com.itwillbs.service;

import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.itwillbs.domain.CommonVO;
import com.itwillbs.persistence.SystemDAOImpl;

@Service
public class SystemServiceImpl implements SystemService {

	
	private static final Logger logger = LoggerFactory.getLogger(SystemServiceImpl.class);
	
	@Inject
	private SystemDAOImpl sdao;

	@Override
	public void registCommons(CommonVO cvo) throws Exception {
		logger.debug("ss : registCommons 실행");
		logger.debug("cvo : " + cvo);
		logger.debug("sdao : " + sdao);
		sdao.registCommons(cvo);
	}

	@Override
	public List<CommonVO> getCommons() throws Exception {
		logger.debug("getCommons 실행");
		return sdao.getCommons();
	}

	@Override
	public CommonVO getOneCommon(CommonVO cvo) throws Exception {
		logger.debug("getCommons 실행");
		return sdao.getOneCommon(cvo);
	}
	
	
	
}
