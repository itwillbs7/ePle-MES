package com.itwillbs.controller;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.itwillbs.domain.CommonVO;
import com.itwillbs.service.SystemServiceImpl;

@Controller
@RequestMapping (value = "/system/*")
public class SystemController {

	
	private static final Logger logger = LoggerFactory.getLogger(SystemController.class);
	@Inject
	private SystemServiceImpl sService;
	
	@GetMapping(value = "/common/main")
	public void commonMain(Model model) throws Exception {
		logger.debug("common 실행");
		// DB로 가서 공통코드 데이터 몽땅 들고오기
		logger.debug("공통코드 리스트 : " + sService.getCommons().toString());
		model.addAttribute("CommonVO",sService.getCommons());
	}
	
	@RequestMapping(value = "/common/add", method = RequestMethod.GET)
	public void commonAddGET() {
		logger.debug("addGET 실행");
		
	}
	
	@RequestMapping(value = "/common/add", method = RequestMethod.POST)
	public String commonAddPOST(@ModelAttribute CommonVO cvo) throws Exception {
		logger.debug("addPOST 실행");
		logger.debug("cvo : " + cvo);
		sService.registCommons(cvo);
		return "redirect:/system/common/registComplete";
		
	}
	
	@GetMapping (value = "/common/registComplete")
	public void commonRegistComplete() {
		logger.debug("registComplete 실행");
	}
	
	@GetMapping (value = "/common/update")
	public void commonUpdateGET(@RequestParam String index, Model model) throws Exception {
		logger.debug("commonUpdateGET 실행");
		logger.debug(index);
		
		// 전달받은 정보의 구분자 위치 at 계산
		int at = index.indexOf('_');
		
		// 전달받은 정보 구분자 at을 통해 subString + cvo에 저장
		CommonVO cvo = new CommonVO();
		logger.debug("group_id : " + index.substring(0, at));
		logger.debug("code_id : " + index.substring(at+1));
		cvo.setGroup_id(index.substring(0, at));
		cvo.setCode_id(index.substring(at+1));
		logger.debug("cvo : " + cvo.toString());
		logger.debug("getOneCommon : " + sService.getOneCommon(cvo));
		
		model.addAttribute("cvo", sService.getOneCommon(cvo));
		
	}
	
	@PostMapping (value = "/common/update")
	public void commonUpdatePOST(@RequestParam String index, CommonVO cvo) throws Exception {
		logger.debug("commonUpdatePOST 실행");
		logger.debug("index : " + index);
		// 수정하기 전 index로 해당 데이터 찾고, 입력받은 값 = cvo으로 수정
		// List배열로 넘겨준다?
		// indexCVO 객체 생성 후 index 정보 배열에 저장, 전달받은 입력 값(cvo) 배열에 저장
		// Mapper로 전달해 꺼내쓰기?
		
		// 전달받은 정보의 구분자 위치 at 계산
		int at = index.indexOf('_');
		
		// 전달받은 정보 구분자 at을 통해 subString + cvo에 저장
		logger.debug("group_id : " + index.substring(0, at));
		logger.debug("code_id : " + index.substring(at+1));
		cvo.setGroup_id(index.substring(0, at));
		cvo.setCode_id(index.substring(at+1));
		logger.debug("cvo : " + cvo.toString());
		
		
	}
	
	@GetMapping (value = "user/main")
	public void user() {
		
	}
	
	@GetMapping(value = "/authority/main")
	public void authority() {
		
	}
	
}
