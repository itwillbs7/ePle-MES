package com.itwillbs.persistence;

import java.util.List;

import com.itwillbs.domain.CommonVO;

public interface SystemDAO {
	
	public void registCommons(CommonVO cvo) throws Exception;
	public List<CommonVO> getCommons() throws Exception;
	public CommonVO getOneCommon(CommonVO cvo) throws Exception;
}
