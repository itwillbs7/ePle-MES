package com.itwillbs.persistence;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.itwillbs.domain.CommonVO;

@Repository
public class SystemDAOImpl implements SystemDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(SystemDAOImpl.class);
	private final String NAMESPACE = "com.itwillbs.mapper.systemMapper";
	@Inject
	private SqlSession sqlSession;
	
	@Override
	public void registCommons(CommonVO cvo) throws Exception {
		logger.debug("dd : registCommons 실행");
		logger.debug("dd : sqlSession = " + sqlSession);
		sqlSession.selectOne(NAMESPACE+".insertCommons", cvo);
		
	}

	@Override
	public List<CommonVO> getCommons() throws Exception {
		logger.debug("getCommons 실행");
		return sqlSession.selectList(NAMESPACE+".selectCommons");
	}

	@Override
	public CommonVO getOneCommon(CommonVO cvo) throws Exception {
		logger.debug("getOneCommon 실행");
		logger.debug("cvo : " + sqlSession.selectOne(NAMESPACE+".selectOneCommon", cvo));
		return sqlSession.selectOne(NAMESPACE+".selectOneCommon", cvo);
	}
	
	
	
}
